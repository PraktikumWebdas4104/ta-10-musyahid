<?php
	//include class controller
	include "controller/controller.php";
	
	//variabel main merupakan objek baru yang dibuat dari class controller
	$main = new controller();
	
	//kondisi untuk menampilkan halaman web yang diminta
	if(isset($_GET['edit'])){ //kondisi untuk mengakses halaman edit
		$nim = $_GET['edit'];
		$main->viewEdit($nim);
	}else if(isset($_GET['delete'])){ //kondisi untuk menghapus data (mengakses fungsi delete)
		$nim = $_GET['delete'];
		$main->delete($nim);
	}else if(isset($_GET['insert'])){
		//kondisi untuk mengakses halaman add
		//panggil controller viewinsert
		$main->viewInsert();
	}else{
		$main->index(); //kondisi awal (menampilkan seluruh data)
	}
?>