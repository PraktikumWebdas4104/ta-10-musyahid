<html>
	<head>
		<title>MVC</title>
	</head>
	<body>
		<form action="" method="POST">
			<table border="1" cellpadding="5" cellspacing="0" align="center">
				<tr align="center">
					<td>NIM</td>
					<td>:</td>
					<td><input type="text" name="nim" value="<?=$row[0]?>" size="45" readonly /></td>
				</tr>
				<tr align="center">
					<td>Nama</td>
					<td>:</td>
					<td><input type="text" name="nama" value="<?=$row[1]?>" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Angkatan</td>
					<td>:</td>
					<td><input type="text" name="angkatan" value="<?=$row[2]?>" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Fakultas</td>
					<td>:</td>
					<td><input type="text" name="fakultas" value="<?=$row[3]?>" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Prodi</td>
					<td>:</td>
					<td><input type="text" name="prodi" value="<?=$row[4]?>" size="45"/></td>
				</tr>

				<tr align="center">
					<td>Genre Film</td>
					<td>:</td>
					<td><input type="checkbox" name="genre[]" value="HORROR" <?php in_array('HORROR',$genre) ? print 'checked' : ' ' ?>> HORROR
					<input type="checkbox" name="genre[]" value="ACTION" <?php in_array('ACTION',$genre) ? print 'checked' : ' ' ?>> ACTION
					<input type="checkbox" name="genre[]" value="ANIME" <?php in_array('ANIME',$genre) ? print 'checked' : ' ' ?>> ANIME
					<input type="checkbox" name="genre[]" value="THRILLER" <?php in_array('THRILLER',$genre) ? print 'checked' : ' ' ?>> THRILLER
					<input type="checkbox" name="genre[]" value="ANIMASI" <?php in_array('ANIMASI',$genre) ? print 'checked' : ' ' ?>> ANIMASI</td>
				</tr>
				<tr align="center">
					<td>Tujuan Travelling</td>
					<td>:</td>
					<td><input type="checkbox" name="travelling[]" value="BALI" <?php in_array('BALI',$travelling) ? print 'checked' : ' ' ?>> BALI
					<input type="checkbox" name="travelling[]" value="RAJA AMPAT" <?php in_array('RAJA AMPAT',$travelling) ? print 'checked' : ' ' ?>> RAJA AMPAT
					<input type="checkbox" name="travelling[]" value="PULAU DERAWAN" <?php in_array('PULAU DERAWAN',$travelling) ? print 'checked' : ' ' ?>> PULAU DERAWAN
					<input type="checkbox" name="travelling[]" value="BANGKA BELITUNG" <?php in_array('BANGKA BELITUNG',$travelling) ? print 'checked' : ' ' ?>> BANGKA BELITUNG
					<input type="checkbox" name="travelling[]" value="LABUAN BAJO" <?php in_array('LABUAN BAJO',$travelling) ? print 'checked' : ' ' ?>> LABUAN BAJO</td>
				</tr>
				<tr align="center">
					<td colspan="3"><input type="submit" name="submit"/></td>
				</tr>
			</table>
		</form>
	</body>
</html>
<?php
	if(isset($_POST['submit'])){ //jika button submit diklik maka panggil fungsi update pada controller
		$main = new controller();
		$main->update();
	}
?>